# NanoPI_Duo2
KICAD Footprint and WRL for the NANOPI DUO2
